# Contributing
- 小さくPR、頻繁にマージ。`eval` 影響はラベル付与。