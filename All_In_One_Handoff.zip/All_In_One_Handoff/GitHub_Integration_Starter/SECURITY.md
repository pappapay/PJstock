# Security
- Secrets/PII はコミット禁止。発見時は即時ローテーション。