# GitHub Integration Plan（株プロジェクト）
- ブランチ戦略: main 保護、feat/* PR前提
- 必須チェック: ci, eval, lint, typecheck, unit-test
- Environments: dev, staging, prod（Secrets登録）
- Workflows: ci/eval/nightly/release（スケルトン）
