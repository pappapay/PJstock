---
name: "Feature request"
about: 新機能提案
labels: ["feat"]
---
## 概要
## 目的 / KPI
## 受け入れ条件（DoD）
## 参考
