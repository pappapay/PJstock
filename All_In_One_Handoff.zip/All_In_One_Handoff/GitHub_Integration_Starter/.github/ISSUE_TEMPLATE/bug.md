---
name: "Bug report"
about: 不具合報告
labels: ["fix"]
---
## 事象
## 再現手順
## 期待結果
## ログ/スクショ
