---
name: "Research task"
about: 調査・検証
labels: ["research"]
---
## 仮説
## アプローチ
## 評価指標
## 期待される成果物
