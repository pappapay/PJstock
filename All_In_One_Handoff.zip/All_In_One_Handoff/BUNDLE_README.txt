# All-in-One Handoff Bundle

- /D_Phase_Specs : D1〜D8（抽象フロー、I/O、評価ハーネス、SLA、Taxonomy、リスク、DoR/DoD、スプリント）
- /GitHub_Integration_Starter : Actions（ci/eval/nightly/release）、Issue/PRテンプレ、CODEOWNERS、SECURITY
- handoff_package_checklist.txt : 引き渡しチェックリスト

使い方：新規リポを作成→GitHubスターターをリポ直下→D_Phase_Specsをdocs/へ→main保護＆Secrets→CodexにIssueで依頼。
